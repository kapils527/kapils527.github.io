﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Assessment_Application
{
    public partial class register : System.Web.UI.Page
    {
        string str;
        SqlCommand cmd;
        SqlCommand cmd1;
        SqlCommand cmd2;
        SqlCommand cmd3;
        SqlCommand cmd4;
        int count;
        protected void Page_Load(object sender, EventArgs e)
        {
            Unique();
        }
        void Unique()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cstring"].ConnectionString);
            con.Open();
            str = "select count(*) from register1";
            cmd = new SqlCommand(str, con);
            //cmd.ExecuteNonQuery();
            count = Convert.ToInt16(cmd.ExecuteScalar()) + 1;
            TextBox1.Text = "S00" + count.ToString();
            con.Close();
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cstring"].ConnectionString);
                con.Open();
                string user = TextBox4.Text;
                str = "select user_name from register1 where user_name=@name";
                cmd1 = new SqlCommand(str, con);
                cmd1.Parameters.AddWithValue("@name", user);
                SqlDataReader dr = cmd1.ExecuteReader();
                if (dr.HasRows == true)
                {
                    Label8.Text = "User Name not Available";
                    TextBox4.Focus();
                    dr.Close();
                }
                else
                    Label8.Text = "User Name Available";
            }
            catch (Exception ex)
            {
                Label14.Text = ex.ToString();
            }
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cstring"].ConnectionString);
                con.Open();
                string user = TextBox4.Text;
                str = "select user_name from register1 where user_name=@name";
                //SqlCommand cmd2;
                cmd2 = new SqlCommand(str, con);
                cmd2.Parameters.AddWithValue("@name", user);
                SqlDataReader dr1 = cmd2.ExecuteReader();
                if (dr1.HasRows == true)
                {
                    Label8.Text = "User Name not Available";
                    TextBox4.Focus();
                    dr1.Close();
                    con.Close();

                }

                else
                {
                    SqlConnection con1 = new SqlConnection(ConfigurationManager.ConnectionStrings["cstring"].ConnectionString);
                    con1.Open();
                    SqlDataAdapter da = new SqlDataAdapter("select * from register1", con1);
                    SqlCommandBuilder cmddbuilder = new SqlCommandBuilder(da);
                    DataSet dts = new DataSet("register1");
                    da.Fill(dts, "register1");
                    DataRow dr;

                    dr = dts.Tables["register1"].NewRow();
                    dr[0] = TextBox1.Text;
                    dr[1] = TextBox2.Text;
                    dr[2] = TextBox3.Text;
                    dr[3] = DropDownList2.SelectedValue;
                    dr[4] = DropDownList1.SelectedValue;
                    dr[5] = TextBox4.Text;
                    dr[6] = TextBox6.Text;
                    dr[7] = DropDownList3.SelectedValue;
                    dr[8] = TextBox7.Text;
                    dr[9] = TextBox8.Text;

                    dts.Tables["register1"].Rows.Add(dr);
                    da.Update(dts, "register1");
                    Label14.Text = "Student Register Successfully";
                    TextBox8.Text = "";
                    TextBox7.Text = "";
                    TextBox6.Text = "";
                    TextBox5.Text = "";
                    TextBox4.Text = "";
                    TextBox3.Text = "";
                    TextBox2.Text = "";
                    TextBox1.Text = "";
                    Label8.Text = "";
                    Unique();

                }
            }
            catch (Exception ex)
            {
                Label14.Text = ex.ToString();
            }
        }
    }
}