﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Student_Assessment_Application
{
    public partial class View_detail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void TextBox7_TextChanged(object sender, EventArgs e)
        {

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            string first = TextBox1.Text;
            string last = TextBox2.Text;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cstring"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from register1 where first_name=@first and last_name=@last", con);
            cmd.Parameters.AddWithValue("first", first);
            cmd.Parameters.AddWithValue("last", last);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows == true && dr.Read())
            {
                Label5.Visible = true;
                Label6.Visible = true;
                Label7.Visible = true;
                Label8.Visible = true;
                Label9.Visible = true;
                Label10.Visible = true;
                Label12.Visible = true;
                Label14.Visible = true;
                Label15.Visible = true;
                Label16.Visible = true;

                TextBox3.Visible = true;
                TextBox4.Visible = true;
                TextBox5.Visible = true;
                TextBox6.Visible = true;
                TextBox7.Visible = true;
                TextBox9.Visible = true;
                TextBox10.Visible = true;
                TextBox11.Visible = true;
                TextBox12.Visible = true;
                TextBox13.Visible = true;
                Button3.Visible = true;
                TextBox3.Text = dr[0].ToString();
                TextBox4.Text = dr[1].ToString();
                TextBox5.Text = dr[2].ToString();
                TextBox6.Text = dr[3].ToString();
                TextBox7.Text = dr[4].ToString();
                TextBox9.Text = dr[5].ToString();
                TextBox10.Text = dr[6].ToString();
                TextBox11.Text = dr[7].ToString();
                TextBox12.Text = dr[8].ToString();
                TextBox13.Text = dr[9].ToString();
            }
            else
                Label4.Text = "Invalid Details";
            con.Close();


        }
        protected void Button3_Click(object sender, EventArgs e)
        {
            Server.Transfer("Login.aspx");
        }
    }
}
