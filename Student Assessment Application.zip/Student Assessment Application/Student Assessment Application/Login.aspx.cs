﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Student_Assessment_Application
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            string user = TextBox1.Text;
            string pass = TextBox2.Text;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cstring"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select First_Name,Last_Name,Class,Section from register1 where user_name=@user and Password=@passw", con);
            cmd.Parameters.AddWithValue("user", user);
            cmd.Parameters.AddWithValue("passw", pass);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Session["name"] = dr[0].ToString() + " " + dr[1].ToString();
                Session["class"] = dr[2].ToString() + " " + dr[3].ToString();
                Response.Redirect("Welcome_login.aspx");
            }
            else
                Label1.Text = "User Name or Password is Incorrect";
        }
    }
}