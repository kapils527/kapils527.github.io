﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Student_Assessment_Application
{
    public partial class Welcome_Login : System.Web.UI.Page
    {
        string q1, q2, q3, q4, q5, q6, q7, q8, q9, q10;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string name = Session["name"].ToString();
                string cl = Session["class"].ToString();
                // string sec = Session["section"].ToString();
                Label1.Text = name + " of " + cl;
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cstring"].ConnectionString);
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter("select * from quiz order by newid()", con);
                SqlCommandBuilder cmddbuilder = new SqlCommandBuilder(da);
                DataSet dts = new DataSet("quiz");
                da.Fill(dts, "quiz");
                DataTable dt = dts.Tables["quiz"];
                DataRow[] dr = dt.Select("");

                Label2.Text = dr[0][1].ToString();
                RadioButtonList1.Items.Add(dr[0][2].ToString());
                RadioButtonList1.Items.Add(dr[0][3].ToString());
                RadioButtonList1.Items.Add(dr[0][4].ToString());
                RadioButtonList1.Items.Add(dr[0][5].ToString());
                q1 = dr[0][6].ToString();
                Label13.Text = q1;

                Label3.Text = dr[1][1].ToString();
                RadioButtonList2.Items.Add(dr[1][2].ToString());
                RadioButtonList2.Items.Add(dr[1][3].ToString());
                RadioButtonList2.Items.Add(dr[1][4].ToString());
                RadioButtonList2.Items.Add(dr[1][5].ToString());
                q2 = dr[1][6].ToString();
                Label14.Text = q2;

                Label4.Text = dr[2][1].ToString();
                RadioButtonList3.Items.Add(dr[2][2].ToString());
                RadioButtonList3.Items.Add(dr[2][3].ToString());
                RadioButtonList3.Items.Add(dr[2][4].ToString());
                RadioButtonList3.Items.Add(dr[2][5].ToString());
                q3 = dr[2][6].ToString();
                Label15.Text = q3;

                Label5.Text = dr[3][1].ToString();
                RadioButtonList4.Items.Add(dr[3][2].ToString());
                RadioButtonList4.Items.Add(dr[3][3].ToString());
                RadioButtonList4.Items.Add(dr[3][4].ToString());
                RadioButtonList4.Items.Add(dr[3][5].ToString());
                q4 = dr[3][6].ToString();
                Label16.Text = q4;

                Label6.Text = dr[4][1].ToString();
                RadioButtonList5.Items.Add(dr[4][2].ToString());
                RadioButtonList5.Items.Add(dr[4][3].ToString());
                RadioButtonList5.Items.Add(dr[4][4].ToString());
                RadioButtonList5.Items.Add(dr[4][5].ToString());
                q5 = dr[4][6].ToString();
                Label17.Text = q5;

                Label7.Text = dr[5][1].ToString();
                RadioButtonList6.Items.Add(dr[5][2].ToString());
                RadioButtonList6.Items.Add(dr[5][3].ToString());
                RadioButtonList6.Items.Add(dr[5][4].ToString());
                RadioButtonList6.Items.Add(dr[5][5].ToString());
                q6 = dr[5][6].ToString();
                Label18.Text = q6;

                Label8.Text = dr[6][1].ToString();
                RadioButtonList7.Items.Add(dr[6][2].ToString());
                RadioButtonList7.Items.Add(dr[6][3].ToString());
                RadioButtonList7.Items.Add(dr[6][4].ToString());
                RadioButtonList7.Items.Add(dr[6][5].ToString());
                q7 = dr[6][6].ToString();
                Label19.Text = q7;

                Label9.Text = dr[7][1].ToString();
                RadioButtonList8.Items.Add(dr[7][2].ToString());
                RadioButtonList8.Items.Add(dr[7][3].ToString());
                RadioButtonList8.Items.Add(dr[7][4].ToString());
                RadioButtonList8.Items.Add(dr[7][5].ToString());
                q8 = dr[7][6].ToString();
                Label20.Text = q8;

                Label10.Text = dr[8][1].ToString();
                RadioButtonList9.Items.Add(dr[8][2].ToString());
                RadioButtonList9.Items.Add(dr[8][3].ToString());
                RadioButtonList9.Items.Add(dr[8][4].ToString());
                RadioButtonList9.Items.Add(dr[8][5].ToString());
                q9 = dr[8][6].ToString();
                Label21.Text = q9;

                Label11.Text = dr[9][1].ToString();
                RadioButtonList10.Items.Add(dr[9][2].ToString());
                RadioButtonList10.Items.Add(dr[9][3].ToString());
                RadioButtonList10.Items.Add(dr[9][4].ToString());
                RadioButtonList10.Items.Add(dr[9][5].ToString());
                q10 = dr[9][6].ToString();
                Label22.Text = q10;
                con.Close();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int result = 0;
            if (RadioButtonList1.Text == "" || RadioButtonList2.Text == "" || RadioButtonList3.Text == "" || RadioButtonList4.Text == "" || RadioButtonList5.Text == "" || RadioButtonList6.Text == "" || RadioButtonList7.Text == "" || RadioButtonList8.Text == "" || RadioButtonList9.Text == "" || RadioButtonList10.Text == "")
            {
                Label12.Text = "All Questions are Compulsory. Please Attempt all Questions !!!";
            }
            else
            {

                if (RadioButtonList1.SelectedItem.Value == Label13.Text)
                {
                    result = result + 1;
                }
                if (RadioButtonList2.SelectedItem.Value == Label14.Text)
                {
                    result = result + 1;
                }
                if (RadioButtonList3.SelectedItem.Value == Label15.Text)
                {
                    result = result + 1;
                }
                if (RadioButtonList4.SelectedItem.Value == Label16.Text)
                {
                    result = result + 1;
                }
                if (RadioButtonList5.SelectedItem.Value == Label17.Text)
                {
                    result = result + 1;
                }
                if (RadioButtonList6.SelectedItem.Value == Label18.Text)
                {
                    result = result + 1;
                }
                if (RadioButtonList7.SelectedItem.Value == Label19.Text)
                {
                    result = result + 1;
                }
                if (RadioButtonList8.SelectedItem.Value == Label20.Text)
                {
                    result = result + 1;
                }
                if (RadioButtonList9.SelectedItem.Value == Label21.Text)
                {
                    result = result + 1;
                }
                if (RadioButtonList10.SelectedItem.Value == Label22.Text)
                {
                    result = result + 1;
                }
                int percent = result * 10;
                string grade;
                if (percent >= 40)
                {
                    grade = "Passed";
                }
                else { grade = "Failed"; }
                string total = "Scored " + percent.ToString() + " % , ";
                string cook;
                int c;
                if (Request.Cookies["Participants"] != null)
                {
                    cook = Request.Cookies["Participants"].Value;
                    c = Convert.ToInt16(cook) - 1;
                    Response.Cookies["Participants"].Value = c.ToString();
                    Response.Cookies["Participant" + cook]["Name"] = Label1.Text.ToString();
                    Response.Cookies["Participant" + cook]["score"] = total;
                    Response.Cookies["Participant" + cook]["grade"] = "Grade : " + grade;
                    Response.Cookies["Participant"].Expires = DateTime.Now.AddDays(5);
                    if (c == 0)
                    {
                        Response.Redirect("result.aspx");
                    }
                    else
                    {
                        Response.Redirect("login.aspx");
                    }
                }

                Response.Redirect("result.aspx");

            }
            //Label12.Text = "You scored " + result + "points";
        }
    }


}