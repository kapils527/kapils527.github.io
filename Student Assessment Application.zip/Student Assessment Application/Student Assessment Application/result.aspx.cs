﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Assessment_Application
{
    public partial class result : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Table tbl = new Table();
            string a = Session["part"].ToString();
            for (int i = 1; i <= Convert.ToInt32(a); i++)
            {
                TableCell tc = new TableCell();
                TableRow tr = new TableRow();
                Label l = new Label();
                l.ID = "label" + i;
                l.Text = Request.Cookies["Participant" + i]["Name"] + Request.Cookies["Participant" + i]["score"] + Request.Cookies["Participant" + i]["grade"];
                l.ForeColor = Color.CornflowerBlue;
                l.Font.Size = FontUnit.XLarge;

                tc.Controls.Add(l);
                tr.Cells.Add(tc);
                tbl.Rows.Add(tr);
                // Response.Write(Request.Cookies["Participant" + i]["Name"]);
                // Response.Write(Request.Cookies["Participant" + i]["score"]);



            }
            Panel1.Controls.Add(tbl);
            //string result = Session["answer"].ToString();
            //Label2.Text = "You Scored" + result + "points";
            //Label2.Text = a;
        }
    }
}