﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Assessment_Application
{
    public partial class forgot_uname : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            string mail = TextBox1.Text;
            string phone = TextBox2.Text;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cstring"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select user_name from register1 where Email=@user and Phone=@passw", con);
            cmd.Parameters.AddWithValue("user", mail);
            cmd.Parameters.AddWithValue("passw", phone);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Label1.Text = " Your User_id is " + dr[0].ToString();
            }
            else
                Label1.Text = "Invalid Details";
        }
    }
}