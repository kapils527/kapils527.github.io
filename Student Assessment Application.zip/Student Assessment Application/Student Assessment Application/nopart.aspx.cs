﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Assessment_Application
{
    public partial class nopart : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            int part = Convert.ToInt32(TextBox1.Text);
            if (part <= 0)
            {
                Label3.Text = "Number of participants Should not be Zero";
            }
            else if (part > 5)
            {
                Label3.Text = "Number of participants Should not be greater than 5";
            }
            else
            {
                Response.Cookies["Participants"].Value = TextBox1.Text;
                Response.Cookies["Participants"].Expires = DateTime.Now.AddDays(1);
                Session["part"] = TextBox1.Text;
                Response.Redirect("login.aspx");
            }

        }
    }
}