<html>
<head>
	<title>E-mandi</title>

	<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
}

li {
    float: left;
}

a:link, a:visited {
    display: block;
    width: 214px;
    font-weight: bold;
    color: #FFFFFF;
    background-color: #98bf21;
    text-align: center;
    padding: 4px;
    text-decoration: none;
    text-transform: uppercase;
}

a:hover, a:active {
    background-color: #7A991A;
}
</style>

</head>
 <body bgcolor="#d0e4fe">

 <img src="1.jpg" width="1332" height="200"><br/>

	<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="report.php">Shopping</a></li>
  <li><a href="opt.php">Vegetables/crops</a></li>
  <li><a href="about.php">AboutUS</a></li>
  <li><a href="contactus.php">ContactUS</a></li>
  <li><a href="admin.php">Login</a></li>
</ul>
<marquee ><h2 style="background-color:yellow;">Welcome to E-Mandi</h2></marquee>

<div align="center">
<table width="1000">
<tr><td>
<h1>Fruit and Vegetable Wholesale Prices (Indian Market) - Market Information Services </h1>
<p>Fruit and Vegetable Wholesale Market Prices are a valuable tool for all sectors of the Industry. Market Information Services is a firm of Fruit and Vegetable Marketing Consultants based in the Indian Markets offering a range of services to all sectors of the Industry, especially in those areas where total impartiality is essential. Our firm has been compiling and distributing Fruit and Vegetable Market Reports in the Indian Markets for nearly twenty years. We supply a range of Market Report options to individual subscribers and the media and also maintain an Historic Database for the Indian Markets.

The Indian Market Reporting Service had been operated by the Department of Primary Industries for many years prior to its privatisation in 1992. Daily Reports were provided to all sectors of the Industry for free or at minimal cost. Market Reports were published and broadcast widely by the radio and print media. That changed with the need to fully fund the Service from the sale of Reports and data supplied to paying subscribers. Some media outlets continue to publish and broadcast Market Reports but many of the major horticultural production areas are now without this service.   

The daily Market prices that are included in our Reports are wholesale selling prices. These are the prices paid by greengrocers, secondary wholesalers, supermarket chains, providores etc. buying in the Indian Markets on the day. Market Reports are used extensively throughout the commercial sector of the Industry to validate the fairness of prices paid for produce, especially in third hand transactions. This high level of  usage and resultant scruitny provides an ongoing check on the accuracy of the information.

Growers can also access this information to assess the fairness of their returns. However, they need to be mindful that wholesale selling prices are subject to deductions for selling fees, stacking and unloading fees, statutory levies and other charges when returns are being calculated. A recent innovation has been the introduction of a Grower Report option. Details of this service and a Growers Order Form appear under the Growers section of this web page.  

Subscribers to Market Reports and historic data need to understand that the information is sourced from the selling floor through our experienced Reporters interviewing as broad a cross section of sellers as possible. However, it is not a complete record of each and every sale of the day and should be regarded as an independent guide of the trading activity on the day rather than a record of actual sales.   </p> 

<h1>Independent Fruit and Vegetable Inspection Services  - Brisbane Market Produce Surveyors</h1>

<p>Brisbane Market Produce Surveyors operates in conjunction with Market Information Services and provides a range of independent inspection and assessment services, primarily with the Brisbane Market. BMPS is also involved in National inspection and monitoring programs in association with produce surveyors based in the other Central Markets and elsewhere. A number of BMPS staff members are registered as Independent Horticultural Assessors under the Horticultural Code of Conduct.  

Our services can be accessed by all Industry sectors and total impartiality is assured in all instances. Inspection Reports are the property of the person requesting the service and the information that they contain will not be divulged to any other party unless formally requested by that person. 

The most common source of disputes between growers and wholesalers is the price paid for produce, especially where this is below the growers expectations. There can be a number of reasons for lower than expected prices and it is important that growers engage the services of an Independent Produce Surveyor as soon as possible after they are advised of potential quality issues. Early intervention assures the best possible outcome and will give important feed back on the nature and severity of the problem as well as an indication of the likely cause where that can be determined. Documentary evidence of downgrading and disposal is also vital in ensuring the highest possible level of transparency in transactions.

The ideal form of protection for growers is to arrange a routine outturn inspection of their produce at the time of arrival. Alternatively, it is also possible to insist that their wholesaler advises them immediately of any quality issues and also ensure that appropriate documentation is in place if produce is downgraded, sold at a reduced price on quality grounds, or disposed of.        

The range of services that are available and sample Reports for some of those options are shown elsewhere on the website. </p>
</td></tr>
</table>
</div>

<hr>


<br/><br/><br/>

 </body>
</html>