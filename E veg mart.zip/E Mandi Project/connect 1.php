<?php

$con=mysql_connect("localhost","root","");
$db=mysql_select_db("emandi1",$con);

if(isset($_REQUEST["Submit"]))
{

$query="select `patato`,`sweet_patato`,`cauliflower`,`tamato`,`cabbage`,`corn`,`carrot`,`pea`,`mushroom` from `veg` ";

$res=mysql_query($query);
echo "$rowvalue['patato']";


	

}

?>