<html>
<head>
<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
}

li {
    float: left;
}

a:link, a:visited {
    display: block;
    width: 214px;
    font-weight: bold;
    color: #FFFFFF;
    background-color: #98bf21;
    text-align: center;
    padding: 4px;
    text-decoration: none;
    text-transform: uppercase;
}

a:hover, a:active {
    background-color: #7A991A;
}
</style>

</head>
 <body bgcolor="#d0e4fe">

 <img src="1.jpg" width="1332" height="200"><br/>

	<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="report.php">Shopping</a></li>
  <li><a href="opt.php">Vegetables/crops</a></li>
  <li><a href="about.php">AboutUS</a></li>
  <li><a href="contactus.php">ContactUS</a></li>
  <li><a href="admin.php">Login</a></li>
</ul>


<form action="contact.php" method="get">
<table>
<tr>
<td> <img src="2.jpg" weight="800" height="300"> </td>
<td style="background-color=yellow">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
<td><div align="right">UserName <input type="text" name="user" placeholder="UserName" ><br/>
Password <input type="password" name="pass" placeholder="Password"><br/>
<input type="submit" name="signin" value="signin"></td>
</table>
</form>


<?php
error_reporting(0);

$name=$_REQUEST['user'];
$pwd=$_REQUEST['pass'];

$con=mysql_connect("localhost","root","");
$db=mysql_select_db("emandi1",$con);

$query="select * from admin where user='$name' and pass='$pwd'";
$res=mysql_query($query);
$count=mysql_num_rows($res);



if(isset($_REQUEST['signin']))
{
	header('Location:contact.php');
}
	


?>

<hr>


<br/><br/><br/>

 </body>
</html>