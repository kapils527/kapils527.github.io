<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
}

li {
    float: left;
}

a:link, a:visited {
    display: block;
    width: 214px;
    font-weight: bold;
    color: #FFFFFF;
    background-color: #98bf21;
    text-align: center;
    padding: 4px;
    text-decoration: none;
    text-transform: uppercase;
}

a:hover, a:active {
    background-color: #7A991A;
}
</style>

</head>
 <body bgcolor="#d0e4fe">

 <img src="1.jpg" width="1332" height="200"><br/>

	<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="report.php">Shopping</a></li>
  <li><a href="opt.php">Vegetables/crops</a></li>
  <li><a href="about.php">AboutUS</a></li>
  <li><a href="contactus.php">ContactUS</a></li>
  <li><a href="admin.php">Login</a></li>
</ul>

<div align="center">
<table width="1000">
<tr><td>
<br/><br/>

<h1>Contact Details</h1>
<br/>
<p>This website is designed,developed and maintained by Hindustan Collage of science of technology.</p>
<br>
<h1>Web information manager</h1>
<br>
<p>Mr Aviansh Chauhan<br/>
Hindustan Collage of Science and technology<br/>
Farah, Mathura</p>
<br/>
<h1>Web Management Team</h1>
<br/>


<h2>Anoop Singh</h2>
<p>(Team Leader)</p><br/>
<h2>Avinash Chauhan</h2>
<p>(Team Member)</p></br>
<h2>Brijesh Shukla</h2>
<p>(Team Member)</p></br>
<h2>Deepika panjwani</h2>
<p>(Team Member)</p></br>

</td></tr></table></div>

<hr>


<br/><br/><br/>

 </body>
</html>