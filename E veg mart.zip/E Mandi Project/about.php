<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
}

li {
    float: left;
}

a:link, a:visited {
    display: block;
    width: 214px;
    font-weight: bold;
    color: #FFFFFF;
    background-color: #98bf21;
    text-align: center;
    padding: 4px;
    text-decoration: none;
    text-transform: uppercase;
}

a:hover, a:active {
    background-color: #7A991A;
}
</style>

</head>
 <body bgcolor="#d0e4fe">

 <img src="1.jpg" width="1332" height="200"><br/>

	<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="report.php">Shopping</a></li>
  <li><a href="opt.php">Vegetables/crops</a></li>
  <li><a href="about.php">AboutUS</a></li>
  <li><a href="contactus.php">ContactUS</a></li>
  <li><a href="admin.php">Login</a></li>
</ul>

<div align="center">
<table width="1000">
<tr><td>
<br/><br/>

<h1>About Market Information Services</h1> 

<p>Market Information Services is a firm of Fruit and Vegetable Marketing Consultants based in the Indian Markets. We offer a range of services to all sectors of the Industry, especially in those areas where total impartiality is essential. Our firm is contracted to operate the Official Market Reporting Service in the Brisbane Markets. We supply a range of Market Report options to individual subscribers and the media and also maintain the Historic Database for the Brisbane Markets.</p>

<p>The Indian Market Reporting Service had been operated by the Department of Primary Industries for many years prior to its privatisation in 1992. Daily Reports were provided to all sectors of the Industry for free or at minimal cost. Market Reports were published and broadcast widely by the radio and print media. That changed with the need to fully fund the Service from the sale of Reports and data supplied to paying subscribers. Some media outlets continue to publish and broadcast Market Reports but many of the major horticultural production areas are now without this service.   </p>

<p>The daily Market prices that are included in our Reports are wholesale selling prices. These are the prices paid by greengrocers, secondary wholesalers, supermarket chains, providores etc. buying in the Indian Markets on the day. Market Reports are used extensively throughout the commercial sector of the Industry to validate the fairness of prices paid for produce, especially in third hand transactions. This high level of  usage and resultant scruitny provides an ongoing check on the accuracy of the information.</p>

<p>Growers can also access this information to assess the fairness of their returns. However, they need to be mindful that wholesale selling prices are subject to deductions for selling fees, stacking and unloading fees, statutory levies and other charges when returns are being calculated. A recent innovation has been the introduction of a Grower Report option. Details of this service as well as a Growers Order Form are included under the Growers section of this wenb page.</p>

<p>Subscribers to Market Reports and historic data need to understand that the information is sourced from the selling floor through our experienced Reporters interviewing as broad a cross section of sellers as possible. However, it is not a complete record of each and every sale of the day and should be regarded as an independent guide of the trading activity on the day rather than a record of actual sales.</p>   

</td></tr></table></div> 

<hr>


<br/><br/><br/>

 </body>
</html>