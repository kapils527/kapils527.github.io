<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
}

li {
    float: left;
}

a:link, a:visited {
    display: block;
    width: 214px;
    font-weight: bold;
    color: #FFFFFF;
    background-color: #98bf21;
    text-align: center;
    padding: 4px;
    text-decoration: none;
    text-transform: uppercase;
}

a:hover, a:active {
    background-color: #7A991A;
}
</style>

</head>
 <body bgcolor="#d0e4fe">

 <img src="1.jpg" width="1332" height="200"><br/>

	<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="report.php">Shopping</a></li>
  <li><a href="opt.php">Vegetables/crops</a></li>
  <li><a href="about.php">AboutUS</a></li>
  <li><a href="contactus.php">ContactUS</a></li>
  <li><a href="admin.php">Admin</a></li>
</ul>
<br/><br/><br/>



<?php
$name=$_REQUEST['user'];
$pwd=$_REQUEST['pass'];

$con=mysql_connect("localhost","root","");
$db=mysql_select_db("emandi1",$con);
$query="select * from admin where user='$name' and pass='$pwd'";
$res=mysql_query($query);
$count=mysql_num_rows($res);

if($count==1)
{
header('Location:signin.php');
}
else
{
 echo "Wrong Username or Password"; 	
}
?>

	<hr>
 </body>
</html>