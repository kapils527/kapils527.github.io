<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
}

li {
    float: left;
}

a:link, a:visited {
    display: block;
    width: 214px;
    font-weight: bold;
    color: #FFFFFF;
    background-color: #98bf21;
    text-align: center;
    padding: 4px;
    text-decoration: none;
    text-transform: uppercase;
}

a:hover, a:active {
    background-color: #7A991A;
}
</style>

</head>
 <body bgcolor="#d0e4fe">

 <img src="1.jpg" width="1332" height="200"><br/>

	<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="report.php">Shopping</a></li>
  <li><a href="opt.php">Vegetables/crops</a></li>
  <li><a href="about.php">AboutUS</a></li>
  <li><a href="contactus.php">ContactUS</a></li>
  <li><a href="admin.php">Login</a></li>
</ul>

<div align="center"><h1>Shop Here...</h1><br/>
(Quantity should be more than 5kgs)</div>
<br/><br/><br/>

<form action="c1.php">
Name &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input name="t1" type="text"  placeholder="Full Name" ><br/><br/>
Address &nbsp&nbsp&nbsp&nbsp&nbsp<input name="t2" type="text"  placeholder="Address" ><br/><br/>
E-Mail &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input name="t3" type="text"  placeholder="email" ><br/><br/>
Mobile No. <input name="t4" type="text"  placeholder="mo." ><br/><br/>


      <p><br/>
  Patato &nbsp;<input name="textfield" type="text"  placeholder="quantity" >
   &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Sweet patato &nbsp;<input name="textfield3" type="text"  placeholder="quantity">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Cauliflower&nbsp;&nbsp;<input name="textfield5" type="text"  placeholder="quantity">
      </p>
      &nbsp;
      <p>Tamato<input name="textfield2" type="text"  placeholder="quantity"> 
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  Cabbage &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <input name="textfield4" type="text"  placeholder="quantity">
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Corn &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <input name="textfield6" type="text"  placeholder="quantity">
      </p>
	  <br/>
	   <p>Carrot&nbsp;&nbsp;<input name="textfield7" type="text"  placeholder="quantity"> 
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  Pea &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <input name="textfield8" type="text"  placeholder="quantity">
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Mushroom&nbsp;&nbsp;
  <input name="textfield9" type="text"  placeholder="quantity">
</p><br/>
<input type="submit" name="Submit" value="ORDER">
</form>
<br/>
    


<br/>

<hr>


<br/><br/><br/>

 </body>
</html>