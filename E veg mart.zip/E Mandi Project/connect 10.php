<html>
<body>
<?php

$con=mysql_connect("localhost","root","");
$db=mysql_select_db("emandi1",$con);

$patato=$_POST["textfield"];
$spatato=$_POST["textfield3"];
$cauliflower=$_POST["textfield5"];
$tamato=$_POST["textfield2"];
$cabbage=$_POST["textfield4"];
$corn=$_POST["textfield6"];
$carrot=$_POST["textfield7"];
$pea=$_POST["textfield8"];
$mushroom=$_POST["textfield9"];



$result = mysql_query("SELECT * FROM `veg` WHERE 1");

while($row = mysql_fetch_array($result))
{
    echo "patato";
    echo "<input type='text'  value='$patato' />";
    echo "S_patato:";
    echo "<input type='text'  value='$spatato' />";
}


?>
</body>
</html>